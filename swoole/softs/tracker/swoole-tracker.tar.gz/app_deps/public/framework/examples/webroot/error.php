<?php

echo "error";

call_not_exist_function();
