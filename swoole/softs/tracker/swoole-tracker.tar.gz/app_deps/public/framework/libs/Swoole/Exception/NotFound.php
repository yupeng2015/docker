<?php
namespace Swoole\Exception;

/**
 * 模块不存在
 * Class NotFound
 * @package Swoole
 */
class NotFound extends \Exception
{

}
